$(function(){

  $(".menu").on("click","a", function (event) {
		event.preventDefault();
		var id  = $(this).attr('href'),
    top = $(id).offset().top;
		$('body,html').animate({scrollTop: top}, 1000);
	});
  
  $('.menu__burger, .menu a').on('click', function(){
    $('.menu').toggleClass('menu--active');
    $('.menu__burger').toggleClass('menu__burger--active');
    
  });

  $('.menu__burger').click(function (event) {
    event.preventDefault();
    $('body').toggleClass('overflow');  
  });

//   $(function() {
//     var menu = $('.menu');  
//     // $('.menu').toggleClass('menu--scroll'); 
//     // var scroll = $('.menu--scroll')  
//     $(window).scroll(function() { 
//       if($(this).scrollTop() > 100) {
//         menu.css({
//           'padding-top': '10px',
//           'padding-bottom': '10px',
//           'transition': '.3s'
//         });
//     } else {
//         menu.css({
//           'padding-top': '75px',
//           'padding-bottom': '10px',
//           'transition': '.3s'
//         });
//       }
//     });
// });

$(window).scroll(function() {
  var height = $(window).scrollTop();
   /*Если сделали скролл на 100px задаём новый класс для header*/
  if(height > 100){
  $('.menu').addClass('menu--fixed');
  console.log('тест');
  } else{
  /*Если меньше 100px удаляем класс для header*/
  $('.menu').removeClass('menu--fixed');
  }
  });



  var Mixer = mixitup ('.portfolio__content');
});

